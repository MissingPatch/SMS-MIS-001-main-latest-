 </body>
  
        </main>
</html>

<script>
$(document).ready(function(){
    $('#sidebar-close-btn').click(function(){
        $('.sidebar').toggleClass("sidebar-close");
        $('.user-profile').toggle();
    });
});
</script>