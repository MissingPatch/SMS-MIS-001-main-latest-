-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jan 22, 2023 at 10:41 AM
-- Server version: 5.0.45
-- PHP Version: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `l6_mis`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `imgupload`
-- 

CREATE TABLE `imgupload` (
  `ID` int(100) NOT NULL auto_increment,
  `img_name` varchar(100) collate latin1_general_ci NOT NULL,
  `type` varchar(100) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=20 ;

-- 
-- Dumping data for table `imgupload`
-- 

INSERT INTO `imgupload` (`ID`, `img_name`, `type`) VALUES 
(19, 'RobloxScreenShot20220626_131422362.png', 'mymind'''),
(18, 'WIN_20220802_00_54_39_Pro.jpg', 'sd'),
(17, 'RobloxScreenShot20220623_224808035.png', '');
